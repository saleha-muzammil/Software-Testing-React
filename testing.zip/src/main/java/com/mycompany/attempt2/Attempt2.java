/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.attempt2;

/**
 *
 * @author saleha
 */
public class Attempt2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
